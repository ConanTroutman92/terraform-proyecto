/*boton informacion 1*/

document.getElementById("btn1").addEventListener("click", ver_json1);
function ver_json1() {


    var xmlhttp = new XMLHttpRequest();
    var url = "js/1-bbi.json";

    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var myArr1 = JSON.parse(this.responseText);
            myFunction(myArr1);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    function myFunction(arr1) {
        var out = "<ul>";
        var i;

        for (i = 0; i < arr1.length; i++) {

            out += '<li>' + arr1[i].tipo + '</li>'
            out += '<li>' + arr1[i].localizacion + '</li>'
            out += '<li>' + arr1[i].horario + '</li>'
            out += '<li>' + arr1[i].precios + '</li>';
        }
        out = out + "</ul>";
        document.getElementById("info1").innerHTML = out;
    }
}



/*boton informacion 2*/

document.getElementById("btn2").addEventListener("click", ver_json2);
function ver_json2() {


    var xmlhttp = new XMLHttpRequest();
    var url = "js/2-da_michele.json";

    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var myArr2 = JSON.parse(this.responseText);
            myFunction(myArr2);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    function myFunction(arr2) {
        var out = "<ul>";
        var i;

        for (i = 0; i < arr2.length; i++) {

            out += '<li>' + arr2[i].tipo + '</li>'
            out += '<li>' + arr2[i].localizacion + '</li>'
            out += '<li>' + arr2[i].horario + '</li>'
            out += '<li>' + arr2[i].precios + '</li>';
        }
        out = out + "</ul>";
        document.getElementById("info2").innerHTML = out;
    }
}



/*boton informacion 3*/

document.getElementById("btn3").addEventListener("click", ver_json3);
function ver_json3() {


    var xmlhttp = new XMLHttpRequest();
    var url = "js/3-vegan_beat.json";

    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var myArr3 = JSON.parse(this.responseText);
            myFunction(myArr3);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    function myFunction(arr3) {
        var out = "<ul>";
        var i;

        for (i = 0; i < arr3.length; i++) {

            out += '<li>' + arr3[i].tipo + '</li>'
            out += '<li>' + arr3[i].localizacion + '</li>'
            out += '<li>' + arr3[i].horario + '</li>'
            out += '<li>' + arr3[i].precios + '</li>';
        }
        out = out + "</ul>";
        document.getElementById("info3").innerHTML = out;
    }
}



/*boton informacion 4*/

document.getElementById("btn4").addEventListener("click", ver_json4);
function ver_json4() {


    var xmlhttp = new XMLHttpRequest();
    var url = "js/4-kaikaya.json";

    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var myArr4 = JSON.parse(this.responseText);
            myFunction(myArr4);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    function myFunction(arr4) {
        var out = "<ul>";
        var i;

        for (i = 0; i < arr4.length; i++) {

            out += '<li>' + arr4[i].tipo + '</li>'
            out += '<li>' + arr4[i].localizacion + '</li>'
            out += '<li>' + arr4[i].horario + '</li>'
            out += '<li>' + arr4[i].precios + '</li>';
        }
        out = out + "</ul>";
        document.getElementById("info4").innerHTML = out;
    }
}




/*tabla informacion*/

document.getElementById("btn-tabla-res").addEventListener("click", mostrarTabla);
function mostrarTabla() {
    document.getElementById("thead-res").style.display = 'table-header-group';
}




document.querySelector("#btn-tabla-res").addEventListener("click", cargarDatos);

function cargarDatos() {

   

    const xhhtp = new XMLHttpRequest();

    xhhtp.open("GET", "js/5-tabla_top10_res.json", true);

    xhhtp.send();

    xhhtp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            

            let datos = JSON.parse(this.responseText);
            
            let res = document.querySelector("#tbody-res");
            res.innerHTML = "";

            for (let item of datos) {
                
                res.innerHTML += `
            <tr>
                <td>${item.nombre}</td>
                <td>${item.tipo}</td>
                <td>${item.localizacion}</td>
                <td>${item.horario}</td>
                <td>${item.precios}</td>
                <td>${item.telefono}</td>
                <td>${item.premios}</td>
                <td>${item.capacidad}</td>
            </tr>
            `
            }
        }

    }

}
